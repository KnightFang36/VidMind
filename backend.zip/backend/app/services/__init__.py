"""RAG business logic."""
