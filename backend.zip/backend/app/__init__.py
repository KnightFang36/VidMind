"""VidMind backend application."""
